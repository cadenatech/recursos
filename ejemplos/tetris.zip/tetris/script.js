const COLS = 10;
const ROWS = 20;
const BLOCK = 30;

const COLORS = {
  I: "#22d3ee",
  O: "#facc15",
  T: "#a78bfa",
  S: "#4ade80",
  Z: "#f87171",
  J: "#60a5fa",
  L: "#fb923c",
};

const SHAPES = {
  I: [[1, 1, 1, 1]],
  O: [
    [1, 1],
    [1, 1],
  ],
  T: [
    [0, 1, 0],
    [1, 1, 1],
  ],
  S: [
    [0, 1, 1],
    [1, 1, 0],
  ],
  Z: [
    [1, 1, 0],
    [0, 1, 1],
  ],
  J: [
    [1, 0, 0],
    [1, 1, 1],
  ],
  L: [
    [0, 0, 1],
    [1, 1, 1],
  ],
};

const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
const nextCanvas = document.getElementById("next");
const nextCtx = nextCanvas.getContext("2d");

const scoreEl = document.getElementById("score");
const linesEl = document.getElementById("lines");
const levelEl = document.getElementById("level");
const statusEl = document.getElementById("status");
const startBtn = document.getElementById("startBtn");

let board;
let currentPiece;
let nextPiece;
let score = 0;
let lines = 0;
let level = 1;
let dropCounter = 0;
let dropInterval = 1000;
let lastTime = 0;
let running = false;
let paused = false;
let animationId = null;

function createBoard() {
  return Array.from({ length: ROWS }, () => Array(COLS).fill(0));
}

function randomPiece() {
  const types = Object.keys(SHAPES);
  const type = types[Math.floor(Math.random() * types.length)];
  return {
    type,
    shape: SHAPES[type].map((row) => [...row]),
    x: Math.floor(COLS / 2) - Math.ceil(SHAPES[type][0].length / 2),
    y: 0,
  };
}

function drawCell(targetCtx, x, y, color, size) {
  targetCtx.fillStyle = color;
  targetCtx.fillRect(x * size, y * size, size, size);
  targetCtx.strokeStyle = "#0f172a";
  targetCtx.lineWidth = 1;
  targetCtx.strokeRect(x * size, y * size, size, size);
}

function drawBoard() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  for (let y = 0; y < ROWS; y += 1) {
    for (let x = 0; x < COLS; x += 1) {
      const cell = board[y][x];
      if (cell) drawCell(ctx, x, y, cell, BLOCK);
      else {
        ctx.strokeStyle = "#111827";
        ctx.strokeRect(x * BLOCK, y * BLOCK, BLOCK, BLOCK);
      }
    }
  }

  if (currentPiece) {
    currentPiece.shape.forEach((row, py) => {
      row.forEach((value, px) => {
        if (value) drawCell(ctx, currentPiece.x + px, currentPiece.y + py, COLORS[currentPiece.type], BLOCK);
      });
    });
  }
}

function drawNextPiece() {
  nextCtx.clearRect(0, 0, nextCanvas.width, nextCanvas.height);
  if (!nextPiece) return;

  const size = 24;
  const shape = nextPiece.shape;
  const xOffset = Math.floor((nextCanvas.width / size - shape[0].length) / 2);
  const yOffset = Math.floor((nextCanvas.height / size - shape.length) / 2);

  shape.forEach((row, y) => {
    row.forEach((value, x) => {
      if (value) drawCell(nextCtx, x + xOffset, y + yOffset, COLORS[nextPiece.type], size);
    });
  });
}

function collides(piece, newX = piece.x, newY = piece.y, shape = piece.shape) {
  for (let y = 0; y < shape.length; y += 1) {
    for (let x = 0; x < shape[y].length; x += 1) {
      if (!shape[y][x]) continue;
      const bx = newX + x;
      const by = newY + y;

      if (bx < 0 || bx >= COLS || by >= ROWS) return true;
      if (by >= 0 && board[by][bx]) return true;
    }
  }
  return false;
}

function mergePiece() {
  currentPiece.shape.forEach((row, y) => {
    row.forEach((value, x) => {
      if (value) {
        const by = currentPiece.y + y;
        if (by >= 0) board[by][currentPiece.x + x] = COLORS[currentPiece.type];
      }
    });
  });
}

function clearLines() {
  let cleared = 0;

  for (let y = ROWS - 1; y >= 0; y -= 1) {
    if (board[y].every((cell) => cell !== 0)) {
      board.splice(y, 1);
      board.unshift(Array(COLS).fill(0));
      cleared += 1;
      y += 1;
    }
  }

  if (cleared > 0) {
    lines += cleared;
    const points = [0, 100, 300, 500, 800][cleared] || 0;
    score += points * level;
    level = Math.floor(lines / 10) + 1;
    dropInterval = Math.max(120, 1000 - (level - 1) * 75);
    updateStats();
  }
}

function rotate(shape) {
  const rows = shape.length;
  const cols = shape[0].length;
  const rotated = Array.from({ length: cols }, () => Array(rows).fill(0));

  for (let y = 0; y < rows; y += 1) {
    for (let x = 0; x < cols; x += 1) {
      rotated[x][rows - 1 - y] = shape[y][x];
    }
  }

  return rotated;
}

function spawnPiece() {
  currentPiece = nextPiece || randomPiece();
  nextPiece = randomPiece();
  drawNextPiece();

  if (collides(currentPiece)) {
    running = false;
    statusEl.textContent = "Game over. Pulsa Iniciar / Reiniciar.";
    cancelAnimationFrame(animationId);
  }
}

function hardDrop() {
  while (!collides(currentPiece, currentPiece.x, currentPiece.y + 1)) {
    currentPiece.y += 1;
    score += 1;
  }
  stepDown();
}

function stepDown() {
  if (!currentPiece) return;

  if (!collides(currentPiece, currentPiece.x, currentPiece.y + 1)) {
    currentPiece.y += 1;
  } else {
    mergePiece();
    clearLines();
    spawnPiece();
  }
  dropCounter = 0;
}

function updateStats() {
  scoreEl.textContent = String(score);
  linesEl.textContent = String(lines);
  levelEl.textContent = String(level);
}

function gameLoop(time = 0) {
  if (!running || paused) return;

  const delta = time - lastTime;
  lastTime = time;
  dropCounter += delta;

  if (dropCounter > dropInterval) {
    stepDown();
  }

  drawBoard();
  animationId = requestAnimationFrame(gameLoop);
}

function resetGame() {
  board = createBoard();
  score = 0;
  lines = 0;
  level = 1;
  dropCounter = 0;
  lastTime = 0;
  dropInterval = 1000;
  paused = false;
  running = true;
  nextPiece = randomPiece();
  spawnPiece();
  updateStats();
  statusEl.textContent = "Jugando";
  drawBoard();
  cancelAnimationFrame(animationId);
  animationId = requestAnimationFrame(gameLoop);
}

function togglePause() {
  if (!running) return;
  paused = !paused;

  if (paused) {
    statusEl.textContent = "Pausa";
  } else {
    statusEl.textContent = "Jugando";
    lastTime = performance.now();
    animationId = requestAnimationFrame(gameLoop);
  }
}

document.addEventListener("keydown", (event) => {
  if (!running) return;

  if (event.key.toLowerCase() === "p") {
    togglePause();
    return;
  }

  if (paused) return;

  if (event.key === "ArrowLeft" && !collides(currentPiece, currentPiece.x - 1, currentPiece.y)) {
    currentPiece.x -= 1;
  } else if (event.key === "ArrowRight" && !collides(currentPiece, currentPiece.x + 1, currentPiece.y)) {
    currentPiece.x += 1;
  } else if (event.key === "ArrowDown") {
    stepDown();
    score += 1;
    updateStats();
  } else if (event.key === "ArrowUp") {
    const rotated = rotate(currentPiece.shape);
    if (!collides(currentPiece, currentPiece.x, currentPiece.y, rotated)) {
      currentPiece.shape = rotated;
    }
  } else if (event.code === "Space") {
    hardDrop();
  }

  drawBoard();
});

startBtn.addEventListener("click", resetGame);

board = createBoard();
drawBoard();
drawNextPiece();
